@echo off
setlocal
cd /d "%~dp0"
set ADR_HOST=0.0.0.0
set ADR_PORT=8080
echo LAN MODE: other approved devices on the same trusted network may connect.
echo Use ipconfig to find this computer's IPv4 address.
echo.
echo IMPORTANT: Text mode works over normal HTTP LAN access.
echo Modern browsers usually block microphone access on http://HOST-IP:8080 because it is not HTTPS.
echo Use localhost for voice testing, or add an approved HTTPS setup before using voice from another computer.
echo.
python app.py
pause
