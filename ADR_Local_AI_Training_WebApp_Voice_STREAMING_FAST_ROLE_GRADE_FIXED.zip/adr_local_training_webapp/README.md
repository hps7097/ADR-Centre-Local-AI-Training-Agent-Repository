# ADR Centre Local AI Training - Fast Streaming Voice Edition

This version keeps the original local Flask + Ollama caller + transcript + grading architecture, but changes the live call path to reduce perceived response delay.

## Main changes

- **Fast live caller:** `qwen3.5:2b`
- **Stronger grader:** `qwen3.5:4b`
- **Streaming Ollama output:** caller text appears as it is generated
- **Thinking disabled for live Qwen calls:** prevents the small caller model spending its output budget in the hidden thinking channel and returning an empty visible reply
- **Early speech:** complete sentences are spoken while the rest of the response is still generating
- **Browser TTS:** uses `speechSynthesis` instead of generating WAV files with `pyttsx3`
- **Caller pre-warm:** the 2B model is loaded in the background when the app starts
- **Fast transcription:** Faster-Whisper `tiny.en`, CPU INT8, `beam_size=1`
- **PyAV compatibility:** `av>=11,<19`
- Text mode remains available as a fallback

## Setup

1. Install Python 3.10+.
2. Install Ollama.
3. Extract the project.
4. Double-click `setup.bat`.
5. The setup script installs Python requirements and attempts to pull:
   - `qwen3.5:2b` for live caller responses
   - `qwen3.5:4b` for grading
6. Double-click `start_local.bat`.
7. Open `http://127.0.0.1:8080` in Chrome or Edge.
8. Allow microphone permission.

## Why this should feel faster

Older path:

`Ollama finishes whole answer -> server TTS creates WAV -> browser downloads WAV -> audio starts`

New path:

`Ollama streams tokens -> browser shows text immediately -> first complete sentence -> browser speaks it while Ollama continues`

This reduces waiting even when total generation time is similar.

## First response

The app starts a background pre-warm request for the live caller model. On slower computers, wait 10-30 seconds after starting the application before beginning the first test.

## Models

Defaults are controlled by environment variables:

- `ADR_CALLER_MODEL=qwen3.5:2b`
- `ADR_GRADER_MODEL=qwen3.5:4b`
- `ADR_WHISPER_MODEL=tiny.en`

`start_local.bat` sets these automatically.

### Even faster caller option

If the client computer is very slow, install:

```bat
ollama pull qwen3.5:0.8b
```

Then edit `start_local.bat`:

```bat
set ADR_CALLER_MODEL=qwen3.5:0.8b
```

This can reduce latency further, but the smaller model may be less consistent at persona role-play.

## Voice behaviour

Voice replies use the browser/Windows speech engine. No server-side voice WAV file is generated. This is intentionally optimised for low latency rather than maximum voice realism.

The browser chooses from installed English voices and applies slightly different speaking rates to the six personas.

## Speech recognition

The browser records microphone audio and sends it to the local Flask app. Faster-Whisper transcribes it locally using `tiny.en`.

The first microphone use may download the Whisper model if it is not already cached.

## Grading

The completed text transcript is still passed to the separate grading agent. Streaming and voice do not change the transcript-based grading design.

## Troubleshooting

### Empty caller response / could not reach caller model

This build disables Qwen thinking for the live caller (`think=False`) and gives the caller a 120-token visible response budget. If you still see this error, first confirm the model itself runs:

```bat
ollama run qwen3.5:2b
```

Type `Hello`, then exit with `/bye`.

### Caller model not found

Run:

```bat
ollama pull qwen3.5:2b
```

### Grader model not found

Run:

```bat
ollama pull qwen3.5:4b
```

### Speech recognition error mentioning `metadata_errors`

Run:

```bat
python -m pip install --upgrade "av>=11,<19"
```

### Browser does not speak

Check that `Speak caller replies` is ticked and Windows/browser audio is not muted. Chrome or Edge is recommended.

### First response is slow

Wait 10-30 seconds after startup for model pre-warming. Check the terminal for `Caller model warmed: qwen3.5:2b`.

### Still too slow

Try `qwen3.5:0.8b` as the caller model while keeping `qwen3.5:4b` for grading.

## Privacy boundary

Use fictional training data during prototype testing. Active call state remains in Python memory and is not automatically written to a transcript database.


ROLE + GRADING FIXES
- The live caller prompt now has a strict role lock: the AI is always the selected customer/caller and the human is always the trainee staff member.
- A short role reminder is added to each live model request to reduce role reversal on the smaller 2B model.
- The grader now has a larger output budget and automatically retries once if structured JSON is incomplete/truncated.
