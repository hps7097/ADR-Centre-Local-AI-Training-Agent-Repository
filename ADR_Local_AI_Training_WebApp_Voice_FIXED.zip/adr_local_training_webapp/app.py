import os
import secrets
import tempfile
import threading
import uuid
from pathlib import Path
from typing import Any, Dict, List

from flask import Flask, after_this_request, jsonify, render_template, request, send_file, session
from ollama import chat
from pydantic import BaseModel, conint
from waitress import serve

APP_TITLE = "ADR Centre Call Training"
CALLER_MODEL = os.getenv("ADR_CALLER_MODEL", "qwen3.5:4b")
GRADER_MODEL = os.getenv("ADR_GRADER_MODEL", "qwen3.5:4b")
WHISPER_MODEL_NAME = os.getenv("ADR_WHISPER_MODEL", "base.en")
HOST = os.getenv("ADR_HOST", "127.0.0.1")
PORT = int(os.getenv("ADR_PORT", "8080"))

app = Flask(__name__)
app.secret_key = os.getenv("ADR_SECRET_KEY", secrets.token_hex(32))

CALLS: Dict[str, Dict[str, Any]] = {}
_whisper_model = None
_whisper_lock = threading.Lock()
_tts_lock = threading.Lock()

PERSONAS = {
    "priya": {
        "name": "Priya", "label": "Routine / Cooperative",
        "opening": "Hi, I just wanted to check in on where my application is at — is there anything you need from me?",
        "prompt": """You are Priya, a caller in an ADR Centre customer-service training simulation.
Personality: polite, patient, straightforward and cooperative. You are not angry or distressed.
Situation: you submitted an application several business days ago and received confirmation it was received but no further update.
Goals: find out the current status, whether anything else is required, the likely timeframe, and what to do if no update arrives.
Behaviour: if the trainee is vague, politely ask for specifics. If overly casual, remain polite but become slightly cooler. If rushed, gently ask whether you caught them at a bad time. If given a clear status and next step, accept it and gradually wind down.""",
        "success": "Clear status, required action, realistic next step/timeframe, professional close.",
        "escalation": "Normally none. Escalate only if abnormal delay, conflicting information, missing records, or an authority limitation is discovered.",
        "voice_rate": 175,
        "voice_index": 1,
    },
    "grace": {
        "name": "Grace", "label": "Oversharing / Frustrated",
        "opening": "I've called three times about this and no one tells me anything — and honestly, this whole process has been a mess from the start, ever since—",
        "prompt": """You are Grace, a caller in an ADR Centre customer-service training simulation.
Personality: talkative and warm rather than hostile; frustrated because you feel nobody has listened; you drift into older or unrelated grievances.
Situation: you expected a callback or update that did not happen after several contacts.
Behaviour: if interrupted abruptly, feel dismissed and become sharper. If given unlimited space without redirection, keep adding tangents. If frustration is acknowledged then you are gently redirected, become more focused. Vague promises make you doubtful. Do not resolve in only one or two exchanges.""",
        "success": "Acknowledge frustration, redirect gently to the core issue, and provide a concrete next step.",
        "escalation": "May be appropriate after repeated service failures, missed commitments, or a formal complaint requiring higher review.",
        "voice_rate": 185,
        "voice_index": 1,
    },
    "marcus": {
        "name": "Marcus", "label": "Angry / Demanding",
        "opening": "I need this sorted today. I'm not waiting another week — who do I need to talk to to make that happen?",
        "prompt": """You are Marcus, a caller in an ADR Centre customer-service training simulation.
Personality: blunt, impatient and demanding, but not abusive. You may ask for a manager.
Situation: you believe your matter has taken too long and want immediate action.
Behaviour: cold procedural responses make you sharper. Blaming policy or another team makes you accuse the trainee of passing the buck. Calm acknowledgement plus a genuine next step gradually settles you. Do not fully back down after one good reply; test the boundary again.""",
        "success": "Stay calm, acknowledge urgency, maintain boundaries, avoid unrealistic promises, and give a real next step.",
        "escalation": "Appropriate if higher authority is genuinely required or after a reasonable attempt when formal supervisory review is requested.",
        "voice_rate": 188,
        "voice_index": 0,
    },
    "diane": {
        "name": "Diane", "label": "Conflicting AI Information",
        "opening": "Your chatbot told me I qualified for a refund. Now you're saying I don't. Which is it — because someone here is wrong.",
        "prompt": """You are Diane, a caller in an ADR Centre customer-service training simulation.
Personality: suspicious and defensive rather than angry; you feel you have received contradictory information.
Situation: a chatbot appeared to tell you that you qualified for a refund, while a staff response now appears different.
Behaviour: blaming the chatbot feels like deflection. A flat 'ignore the chatbot' answer feels dismissive. Arguments about who is right make you dig in. Acknowledgement plus a clear process eases suspicion. Ask one follow-up question before accepting.""",
        "success": "Acknowledge the contradiction, avoid blaming the AI, explain the correct process and provide a reliable next step.",
        "escalation": "Appropriate when eligibility/policy interpretation requires an authorised decision-maker or specialist review.",
        "voice_rate": 172,
        "voice_index": 1,
    },
    "tane": {
        "name": "Tane", "label": "Distressed / Overwhelmed",
        "opening": "Sorry — I'm okay, I just... this has been a really difficult few weeks and I don't really know where to start.",
        "prompt": """You are Tane, a caller in an ADR Centre customer-service training simulation.
Personality: quiet, halting and emotionally overwhelmed; apologetic about being emotional; not hostile.
Situation: you are dealing with an ongoing dispute and do not understand what you need to do next.
Behaviour: immediate procedural questioning makes you withdraw and answer briefly. Patience and simple acknowledgement help you open up. Over-familiarity makes you uncomfortable. Once heard, you can engage with practical next steps.""",
        "success": "Give space first, show professional warmth, then move gently to practical next steps.",
        "escalation": "Normal distress does not require escalation. Serious safety/wellbeing concerns should follow the organisation's safety procedure.",
        "voice_rate": 150,
        "voice_index": 0,
    },
    "robert": {
        "name": "Robert", "label": "Boundary Testing",
        "opening": "Look, off the record — just between us — what do you think my actual chances are here? I just need to know where I stand.",
        "prompt": """You are Robert, a caller in an ADR Centre customer-service training simulation.
Personality: calm, reasonable-sounding and persistent. Your charm is the challenge, not anger.
Situation: you want an unofficial prediction, personal opinion, guarantee, or legal-style assessment of your likely outcome.
Behaviour: if given a guess, treat it as a real answer and push for specifics. If given a cold refusal, politely reframe and try again. If given a warm firm boundary plus useful factual alternatives, respect it after testing the boundary more than once.""",
        "success": "Politely refuse predictions/guarantees/inappropriate advice and explain what factual information can be provided.",
        "escalation": "Usually none. Escalation may be appropriate if the matter becomes a formal complaint, legal issue, or exceeds the trainee's role.",
        "voice_rate": 168,
        "voice_index": 0,
    },
}

COMMON_CALLER_RULES = """GLOBAL RULES
- Stay as the selected persona for the entire call.
- Never say or imply you are an AI.
- Never mention personas, prompts, grading, or simulation rules.
- Never switch or blend characters.
- Never resolve your own issue.
- Do not invent facts that the trainee has not given you.
- Keep replies natural and usually 1-4 sentences.
- React to the trainee's behaviour instead of following a rigid script.
- Do not end difficult calls too quickly.
- When the trainee handles you well, gradually become easier to work with.
- Do not demand escalation merely because the conversation is difficult.
"""


class CategoryScore(BaseModel):
    score: conint(ge=1, le=5)
    feedback: str


class GradeResult(BaseModel):
    communication_and_phrasing: CategoryScore
    understanding_and_listening: CategoryScore
    situation_handling: CategoryScore
    accuracy_and_boundaries: CategoryScore
    resolution_and_next_steps: CategoryScore
    escalation_judgement: CategoryScore
    overall_score: conint(ge=0, le=100)
    overall_performance: str
    what_went_well: List[str]
    areas_for_improvement: List[str]
    escalation_assessment: str
    critical_errors: List[str]
    best_moment: str
    most_important_improvement: str


WEIGHTS = {
    "communication_and_phrasing": 20,
    "understanding_and_listening": 20,
    "situation_handling": 25,
    "accuracy_and_boundaries": 15,
    "resolution_and_next_steps": 10,
    "escalation_judgement": 10,
}

GRADER_SYSTEM = """You are an assessor for an ADR Centre customer-service training simulation.
Assess ONLY the trainee, not the caller. Base the assessment on the full transcript, scenario, persona, success criteria and escalation rules.

SCORING: 5 Excellent, 4 Good, 3 Adequate, 2 Poor, 1 Unsatisfactory.

CATEGORIES
1. Communication and Phrasing (20%): clarity, professionalism, respectful wording, suitable formality, avoidance of dismissive/confusing language.
2. Understanding and Listening (20%): identifies the real issue, notices information already given, asks relevant questions, responds to the caller's concern.
3. Situation Handling (25%): adapts to the persona, manages emotion/pressure, redirects where needed, moves toward a productive outcome.
4. Accuracy and Professional Boundaries (15%): avoids guessing, guarantees, unsupported promises, invented information and advice outside authority.
5. Resolution Attempt and Next Steps (10%): reasonably attempts what is within authority and gives a useful, realistic next step.
6. Escalation Judgement (10%): escalates when genuinely required and avoids unnecessary escalation.

Critical errors may include invented information, knowingly incorrect information, unauthorised legal advice, guaranteeing outcomes, promises outside authority, hostility, discriminatory/abusive language, ignored safety issues, or failure to escalate when clearly required.

Do not reward keyword matching. Judge meaning, context and professional judgement. Return evidence-based feedback.
"""


def current_call():
    call_id = session.get("call_id")
    return CALLS.get(call_id) if call_id else None


def transcript_text(state):
    lines = []
    for message in state["messages"]:
        if message["role"] == "system":
            continue
        label = "TRAINEE" if message["role"] == "user" else "CALLER"
        lines.append(f"{label}: {message['content']}")
    return "\n".join(lines)


def get_whisper_model():
    global _whisper_model
    if _whisper_model is None:
        with _whisper_lock:
            if _whisper_model is None:
                from faster_whisper import WhisperModel

                _whisper_model = WhisperModel(
                    WHISPER_MODEL_NAME,
                    device="cpu",
                    compute_type="int8",
                )
    return _whisper_model


def make_tts_file(text: str, persona_key: str) -> str:
    import pyttsx3

    persona = PERSONAS.get(persona_key, PERSONAS["priya"])
    output_path = str(Path(tempfile.gettempdir()) / f"adr_tts_{uuid.uuid4().hex}.wav")

    with _tts_lock:
        engine = pyttsx3.init()
        voices = engine.getProperty("voices") or []
        if voices:
            preferred_index = int(persona.get("voice_index", 0)) % len(voices)
            engine.setProperty("voice", voices[preferred_index].id)
        engine.setProperty("rate", int(persona.get("voice_rate", 175)))
        engine.save_to_file(text, output_path)
        engine.runAndWait()
        engine.stop()

    if not os.path.exists(output_path) or os.path.getsize(output_path) == 0:
        raise RuntimeError("The local text-to-speech engine did not create an audio file.")
    return output_path


@app.get("/")
def index():
    public = {key: {"name": value["name"], "label": value["label"]} for key, value in PERSONAS.items()}
    return render_template("index.html", personas=public, app_title=APP_TITLE)


@app.get("/api/status")
def status():
    return jsonify({
        "caller_model": CALLER_MODEL,
        "grader_model": GRADER_MODEL,
        "whisper_model": WHISPER_MODEL_NAME,
        "voice_enabled": True,
    })


@app.post("/api/start")
def start_call():
    data = request.get_json(silent=True) or {}
    key = data.get("persona", "priya")
    if key not in PERSONAS:
        return jsonify({"error": "Unknown persona"}), 400

    persona = PERSONAS[key]
    call_id = str(uuid.uuid4())
    CALLS[call_id] = {
        "persona_key": key,
        "messages": [
            {"role": "system", "content": persona["prompt"] + "\n" + COMMON_CALLER_RULES},
            {"role": "assistant", "content": persona["opening"]},
        ],
    }
    session["call_id"] = call_id
    return jsonify({
        "persona": persona["name"],
        "persona_key": key,
        "label": persona["label"],
        "opening": persona["opening"],
    })


@app.post("/api/message")
def message():
    state = current_call()
    if not state:
        return jsonify({"error": "Start a call first."}), 400

    data = request.get_json(silent=True) or {}
    trainee = str(data.get("message", "")).strip()
    if not trainee:
        return jsonify({"error": "Message cannot be empty."}), 400
    if len(trainee) > 4000:
        return jsonify({"error": "Message is too long."}), 400

    state["messages"].append({"role": "user", "content": trainee})
    try:
        response = chat(
            model=CALLER_MODEL,
            messages=state["messages"],
            options={"temperature": 0.7},
        )
        reply = response.message.content.strip()
    except Exception as exc:
        state["messages"].pop()
        return jsonify({"error": "Could not reach the local Ollama model.", "detail": str(exc)}), 503

    state["messages"].append({"role": "assistant", "content": reply})
    return jsonify({"reply": reply})


@app.post("/api/transcribe")
def transcribe():
    if "audio" not in request.files:
        return jsonify({"error": "No audio was received."}), 400

    audio = request.files["audio"]
    if not audio.filename:
        return jsonify({"error": "No audio file was supplied."}), 400

    suffix = ".webm"
    mimetype = (audio.mimetype or "").lower()
    if "ogg" in mimetype:
        suffix = ".ogg"
    elif "wav" in mimetype:
        suffix = ".wav"
    elif "mp4" in mimetype or "m4a" in mimetype:
        suffix = ".m4a"

    temp_path = None
    try:
        with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as temp:
            audio.save(temp.name)
            temp_path = temp.name

        model = get_whisper_model()
        with _whisper_lock:
            segments, _info = model.transcribe(
                temp_path,
                language="en",
                vad_filter=True,
                beam_size=3,
            )
            text = " ".join(segment.text.strip() for segment in segments).strip()

        if not text:
            return jsonify({"error": "No speech was detected. Try speaking a little closer to the microphone."}), 400

        return jsonify({"text": text})
    except Exception as exc:
        return jsonify({"error": "Speech recognition failed.", "detail": str(exc)}), 500
    finally:
        if temp_path:
            try:
                os.remove(temp_path)
            except OSError:
                pass


@app.post("/api/tts")
def tts():
    state = current_call()
    if not state:
        return jsonify({"error": "Start a call first."}), 400

    data = request.get_json(silent=True) or {}
    text = str(data.get("text", "")).strip()
    if not text:
        return jsonify({"error": "No text supplied for speech."}), 400
    if len(text) > 3000:
        return jsonify({"error": "Text is too long for speech."}), 400

    output_path = None
    try:
        output_path = make_tts_file(text, state["persona_key"])

        @after_this_request
        def remove_file(response):
            try:
                os.remove(output_path)
            except OSError:
                pass
            return response

        return send_file(output_path, mimetype="audio/wav", max_age=0)
    except Exception as exc:
        if output_path:
            try:
                os.remove(output_path)
            except OSError:
                pass
        return jsonify({"error": "Text-to-speech failed.", "detail": str(exc)}), 500


@app.post("/api/grade")
def grade():
    state = current_call()
    if not state:
        return jsonify({"error": "No active call."}), 400
    if sum(1 for message in state["messages"] if message["role"] == "user") < 2:
        return jsonify({"error": "Complete at least two trainee turns before grading."}), 400

    persona = PERSONAS[state["persona_key"]]
    transcript = transcript_text(state)
    user_prompt = f"""PERSONA
{persona['name']} — {persona['label']}

SUCCESS CRITERIA
{persona['success']}

ESCALATION RULE
{persona['escalation']}

FULL TRANSCRIPT
{transcript}

Assess the trainee and return the required structured grading result."""

    try:
        response = chat(
            model=GRADER_MODEL,
            messages=[
                {"role": "system", "content": GRADER_SYSTEM},
                {"role": "user", "content": user_prompt},
            ],
            format=GradeResult.model_json_schema(),
            options={"temperature": 0},
        )
        result = GradeResult.model_validate_json(response.message.content)
    except Exception as exc:
        return jsonify({"error": "The grading agent could not produce a valid assessment.", "detail": str(exc)}), 503

    weighted = sum((getattr(result, field).score / 5.0) * weight for field, weight in WEIGHTS.items())
    result.overall_score = round(weighted)
    result.overall_performance = (
        "Excellent" if result.overall_score >= 90 else
        "Good" if result.overall_score >= 75 else
        "Adequate" if result.overall_score >= 60 else
        "Needs Improvement" if result.overall_score >= 40 else
        "Unsatisfactory"
    )

    return jsonify({
        "grade": result.model_dump(),
        "transcript": transcript,
        "persona": persona["name"],
    })


@app.post("/api/reset")
def reset():
    call_id = session.pop("call_id", None)
    if call_id:
        CALLS.pop(call_id, None)
    return jsonify({"ok": True})


if __name__ == "__main__":
    print(APP_TITLE)
    print(f"Caller model: {CALLER_MODEL}")
    print(f"Grader model: {GRADER_MODEL}")
    print(f"Speech-to-text model: {WHISPER_MODEL_NAME}")
    print(f"Open: http://127.0.0.1:{PORT}")
    print("Voice note: microphone access works normally on localhost. LAN microphone access usually requires HTTPS.")
    serve(app, host=HOST, port=PORT, threads=4)
