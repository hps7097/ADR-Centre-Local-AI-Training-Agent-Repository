@echo off
setlocal
cd /d "%~dp0"
set ADR_HOST=0.0.0.0
set ADR_PORT=8080
set ADR_CALLER_MODEL=qwen3.5:2b
set ADR_GRADER_MODEL=qwen3.5:4b
set ADR_WHISPER_MODEL=tiny.en
echo Starting ADR Centre FAST STREAMING training app for approved LAN testing...
echo.
echo On the host computer, run ipconfig and use the IPv4 address from another approved computer:
echo http://HOST-IP:8080
 echo.
echo IMPORTANT: Do not expose port 8080 to the public internet.
echo Browser microphone access over plain HTTP LAN addresses may be blocked; text mode should still work.
python app.py
pause
