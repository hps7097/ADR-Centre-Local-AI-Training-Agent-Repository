@echo off
setlocal
cd /d "%~dp0"
set ADR_HOST=0.0.0.0
set ADR_PORT=8080
echo LAN MODE: other devices on the same trusted network may connect.
echo Use ipconfig to find this computer's IPv4 address.
python app.py
pause
