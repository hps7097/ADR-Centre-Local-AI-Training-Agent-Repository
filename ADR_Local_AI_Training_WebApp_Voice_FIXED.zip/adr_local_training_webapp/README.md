# ADR Centre Local AI Training Web App — Voice Edition

This version keeps the original local Caller Agent and Grading Agent and adds local voice functionality.

## Features

- Six selectable ADR caller personas.
- Local Ollama caller agent.
- Separate local Ollama grading agent.
- Text training mode.
- Voice + text training mode.
- Microphone recording in the browser.
- Local speech-to-text using Faster-Whisper.
- Transcription preview before the trainee sends the message.
- Local text-to-speech using the computer's installed voices through `pyttsx3`.
- Spoken opening and caller replies when **Speak caller replies** is enabled.
- Existing six-part weighted grading rubric remains unchanged.
- Active call state remains in memory; transcripts are not automatically written to a database.

## Recommended Windows setup

### 1. Install Python

Install Python 3.10 or newer. During installation, enable **Add Python to PATH** if available.

Check it in Command Prompt:

    python --version

### 2. Install Ollama

Install Ollama using the approved method for the computer.

Then open Command Prompt and run:

    ollama pull qwen3.5:4b

Test it with:

    ollama run qwen3.5:4b

Type a short message. If it replies, enter:

    /bye

### 3. Install this app's Python packages

Extract the whole ZIP. Keep all files and folders together.

Double-click:

    setup.bat

This installs Flask, Ollama Python support, Pydantic, Waitress, Faster-Whisper and pyttsx3.

### 4. Start the local website

Double-click:

    start_local.bat

The browser should open:

    http://127.0.0.1:8080

Keep the Command Prompt window open while using the app.

### 5. First voice test

1. Select **Priya — Routine / Cooperative**.
2. Leave **Training mode** set to **Voice + text**.
3. Click **Start new call**.
4. The caller text appears and the computer should speak the opening.
5. Click **Start speaking**.
6. Allow microphone access in Chrome/Edge if asked.
7. Speak your response.
8. Click **Stop & transcribe**.
9. The first microphone use loads/downloads the configured Whisper model (`base.en` by default). This can take longer than later turns.
10. Review the transcription in the text box.
11. Correct it if necessary.
12. Click **Send response**.
13. Ollama generates the caller reply and the local TTS engine speaks it.
14. Complete at least two trainee turns, then click **End & grade call**.

## Voice architecture

    Microphone
        -> browser MediaRecorder
        -> /api/transcribe
        -> Faster-Whisper (local)
        -> trainee text
        -> existing /api/message
        -> Ollama caller agent
        -> caller text
        -> /api/tts
        -> local computer voice

The text transcript remains the source used by the grading agent, so voice does not change the grading design.

## Text-only mode

If microphone or speech output is unavailable, choose **Text only** from the Training mode menu. The original typed workflow still works.

## Speech-to-text model

Default:

    base.en

It is a lightweight English Whisper model suitable for initial testing.

To try a stronger model on a more powerful computer, open Command Prompt in the app folder and run:

    set ADR_WHISPER_MODEL=small.en
    python app.py

Larger models normally require more memory and are slower on CPU.

## Caller and grader models

Defaults:

    qwen3.5:4b

You can override them before starting the app:

    set ADR_CALLER_MODEL=qwen3.5:4b
    set ADR_GRADER_MODEL=qwen3.5:4b
    python app.py

If the hardware supports a larger grader, it can be tested separately.

## Local voice behaviour

Text-to-speech uses voices already available to the operating system through `pyttsx3`. Personas use slightly different speech rates and, where multiple system voices exist, different voice indexes.

The exact voice depends on what is installed on the client computer. This is intentionally a simple prototype implementation. A later version can replace `pyttsx3` with a higher-quality approved local neural TTS system such as Piper without changing the caller/grading architecture.

## Same-computer access

Use:

    start_local.bat

and open:

    http://127.0.0.1:8080

This is the recommended way to test voice because browsers allow microphone access on localhost.

## LAN access

Use:

    start_lan.bat

Find the host computer's IPv4 address with:

    ipconfig

A second approved computer can open, for example:

    http://192.168.1.25:8080

### Important voice limitation on LAN

Modern browsers treat microphone capture as a secure-context feature. `http://127.0.0.1` / localhost is normally allowed, but plain `http://192.168.x.x:8080` commonly is not.

Therefore:

- text mode can be tested over the LAN HTTP link;
- voice should initially be tested on the host computer using localhost;
- voice from other client computers should use an organisation-approved HTTPS deployment rather than weakening browser security settings.

Do not expose port 8080 directly to the public internet.

## Privacy behaviour

This prototype is intended for fictional training data only.

- Ollama runs locally.
- Faster-Whisper runs locally after its model is available.
- pyttsx3 uses local operating-system speech voices.
- active call state is held in Python memory;
- the app does not automatically create a transcript database;
- temporary microphone and generated speech files are deleted after processing.

Before using real client information, the organisation should approve authentication, storage, retention, access control, network deployment and privacy/security requirements.

## Troubleshooting

### Microphone button does not work

- Use a current Chrome or Edge browser.
- Make sure you opened `http://127.0.0.1:8080` on the same computer.
- Allow microphone permission when prompted.
- Check Windows Settings -> Privacy & security -> Microphone and ensure microphone access is enabled.
- If using a LAN IP address, switch back to localhost for voice testing.

### First transcription is slow

The Whisper model may be downloading/loading for the first time. Later recordings should avoid the initial model-load delay.

### Speech recognition fails

Check the terminal window for the detailed error. Confirm the Python packages installed successfully by running:

    python -m pip install -r requirements.txt

### Caller does not speak

- Make sure **Speak caller replies** is enabled.
- Check Windows sound output and volume.
- Confirm `pyttsx3` installed successfully.
- Text mode and grading can still work if TTS is unavailable.

### Ollama connection error

Run:

    ollama run qwen3.5:4b

If the model does not start there, fix Ollama before testing the web app.

### Website does not load

Keep `start_local.bat` running and manually open:

    http://127.0.0.1:8080

Check that another program is not already using port 8080.

## Suggested client demonstration order

1. Start with Priya in Text only mode and confirm the original workflow.
2. Switch to Voice + text mode.
3. Test microphone transcription.
4. Confirm the trainee can edit the transcription before sending.
5. Confirm caller replies are spoken.
6. Complete a multi-turn call.
7. End and grade the call.
8. Compare the grade against a human-marked version of the same call.

## Important prototype limitations

- No user authentication.
- In-memory call sessions only.
- OS text-to-speech quality varies by computer.
- Whisper accuracy depends on microphone quality, accent, room noise and model size.
- AI grading should be validated against human-marked calls before it is used for assessment.
- Persona wording, policy information and escalation rules should be reviewed by ADR Centre staff.

PYAV / FASTER-WHISPER COMPATIBILITY NOTE
-----------------------------------------
PyAV 19 removed the metadata_errors parameter used by the current Faster-Whisper audio decoder.
This project pins PyAV to a compatible release (av>=11,<19). If you previously installed PyAV 19,
running setup.bat again will downgrade it automatically.

Manual repair command:
    python -m pip install --upgrade "av>=11,<19"

Then restart the web app.
