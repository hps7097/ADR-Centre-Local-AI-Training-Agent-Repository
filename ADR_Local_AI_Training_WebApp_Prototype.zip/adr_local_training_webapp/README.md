# ADR Centre Local AI Training Web App

A simple browser-based prototype with:
- a local Caller Agent,
- a separate local Grading Agent,
- six selectable personas,
- the agreed weighted assessment rubric.

## Setup

1. Install Python 3.10+.
2. Install Ollama.
3. Run `setup.bat`.
4. Run:

    ollama pull qwen3.5:4b

5. Double-click `start_local.bat`.
6. Open `http://127.0.0.1:8080`.

## Client access model

### Same client computer
Use `start_local.bat`.
Bookmark `http://127.0.0.1:8080`.

This gives the client a normal website experience while the model and app run locally on that machine.

### Other computers on the same internal network
Use `start_lan.bat`.

Run `ipconfig` on the host machine and find its IPv4 address, for example `192.168.1.25`.

Other approved computers on the same network can then open:

    http://192.168.1.25:8080

Windows Firewall may require permission.

Do not expose port 8080 directly to the public internet.

### Remote/public access
For users outside the client's LAN, move the web layer to an approved HTTPS hosting environment (for example the client's Azure environment) and use an approved AI/data architecture. Do not expose the local server directly.

## Architecture

Browser
-> Flask/Waitress web app
-> Caller Agent (Ollama)
-> transcript
-> Grading Agent (Ollama structured output)
-> weighted score + feedback

## Grading weights

- Communication and Phrasing: 20%
- Understanding and Listening: 20%
- Situation Handling: 25%
- Accuracy and Professional Boundaries: 15%
- Resolution Attempt and Next Steps: 10%
- Escalation Judgement: 10%

Python calculates the final weighted score from the model's six category scores.

## Model configuration

Default:
- Caller: `qwen3.5:4b`
- Grader: `qwen3.5:4b`

If hardware permits, a larger grader may be more reliable:

    set ADR_GRADER_MODEL=qwen3.5:9b

## Privacy behaviour

This prototype keeps active calls in memory only and does not automatically save transcripts or send them to a cloud AI service.

Before adding persistent records, define:
- access controls,
- retention period,
- who can view results,
- whether real client information is prohibited,
- approved storage location.

## Important prototype limitations

- Text-only for now.
- No authentication.
- In-memory sessions only.
- AI grading must be validated against human-marked sample calls before real assessment use.
- Personas and escalation rules should be reviewed by ADR Centre staff.
- Speech and VR integration should come after the browser prototype is stable.
