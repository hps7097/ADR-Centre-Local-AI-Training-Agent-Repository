@echo off
setlocal
cd /d "%~dp0"
echo ==================================================
echo ADR Centre Local AI Training - Setup
echo ==================================================
echo.
echo Installing Python packages, including local voice support...
python -m pip install --upgrade pip
python -m pip install --upgrade "av>=11,<19"
python -m pip install -r requirements.txt
if errorlevel 1 (
  echo.
  echo Setup failed. Check that Python 3.10+ is installed and available as python.
  pause
  exit /b 1
)
echo.
echo Python packages installed.
echo.
echo Next steps:
echo 1. Install Ollama if needed.
echo 2. Run: ollama pull qwen3.5:4b
echo 3. Double-click start_local.bat
echo 4. In Chrome or Edge, allow microphone access when asked.
echo.
echo NOTE: The Whisper speech model downloads automatically the first time you use the microphone.
echo       Internet is needed for that first model download unless it was pre-cached.
pause
