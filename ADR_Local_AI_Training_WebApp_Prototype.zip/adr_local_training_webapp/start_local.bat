@echo off
setlocal
cd /d "%~dp0"
set ADR_HOST=127.0.0.1
set ADR_PORT=8080
start "" "http://127.0.0.1:8080"
python app.py
pause
