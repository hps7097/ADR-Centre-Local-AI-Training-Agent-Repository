@echo off
setlocal
cd /d "%~dp0"
echo ==================================================
echo ADR Centre Local AI Training - FAST STREAMING Setup
echo ==================================================
echo.
echo Installing Python packages...
python -m pip install --upgrade pip
python -m pip install --upgrade "av>=11,<19"
python -m pip install -r requirements.txt
if errorlevel 1 (
  echo.
  echo Setup failed. Check that Python 3.10+ is installed and available as python.
  pause
  exit /b 1
)

echo.
echo Pulling the fast live caller model: qwen3.5:2b
ollama pull qwen3.5:2b
if errorlevel 1 (
  echo.
  echo WARNING: Could not pull qwen3.5:2b automatically.
  echo Run this later: ollama pull qwen3.5:2b
)

echo.
echo Pulling the stronger grading model: qwen3.5:4b
ollama pull qwen3.5:4b
if errorlevel 1 (
  echo.
  echo WARNING: Could not pull qwen3.5:4b automatically.
  echo Run this later: ollama pull qwen3.5:4b
)

echo.
echo Setup complete.
echo.
echo Next step: double-click start_local.bat
echo.
echo NOTE: The tiny.en Whisper speech model downloads automatically the first time
 echo      you use the microphone, unless it is already cached.
pause
