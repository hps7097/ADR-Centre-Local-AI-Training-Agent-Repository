@echo off
setlocal
cd /d "%~dp0"
set ADR_HOST=127.0.0.1
set ADR_PORT=8080
set ADR_CALLER_MODEL=qwen3.5:2b
set ADR_GRADER_MODEL=qwen3.5:4b
set ADR_WHISPER_MODEL=tiny.en
echo ==================================================
echo ADR Centre Local AI Training - FAST STREAMING
 echo ==================================================
echo Live caller model: qwen3.5:2b
 echo Grader model: qwen3.5:4b
 echo Speech model: tiny.en
 echo Browser: http://127.0.0.1:8080
 echo.
echo Keep this window open while using the app.
start "" "http://127.0.0.1:8080"
python app.py
pause
