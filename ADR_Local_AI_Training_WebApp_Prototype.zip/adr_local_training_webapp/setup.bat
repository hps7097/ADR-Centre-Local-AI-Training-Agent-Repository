@echo off
setlocal
cd /d "%~dp0"
echo Installing Python packages...
python -m pip install -r requirements.txt
if errorlevel 1 (
  echo Setup failed. Check that Python is installed and available as python.
  pause
  exit /b 1
)
echo.
echo Next:
echo 1. Install Ollama if needed.
echo 2. Run: ollama pull qwen3.5:4b
echo 3. Double-click start_local.bat
pause
