@echo off
setlocal
cd /d "%~dp0"
set ADR_HOST=127.0.0.1
set ADR_PORT=8080
echo Starting ADR Centre training app on this computer...
echo Browser address: http://127.0.0.1:8080
echo.
echo Keep this window open while using the app.
start "" "http://127.0.0.1:8080"
python app.py
pause
